#include "number1.h"
#include "ui_number1.h"
#include"password.h"
number1::number1(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::number1)
{
    ui->setupUi(this);
}

number1::~number1()
{
    delete ui;
}

void number1::on_pushButton_clicked()
{
    password p1;
    p1.setModal(true);
    p1.exec();

}

