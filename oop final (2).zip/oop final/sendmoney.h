#ifndef SENDMONEY_H
#define SENDMONEY_H
#include<QString>
#include <QDialog>
#include <QCoreApplication>
#include <QVariant>
#include <iostream>
namespace Ui {
class sendmoney;
}

class sendmoney : public QDialog
{
    Q_OBJECT

public:
    explicit sendmoney(QWidget *parent = nullptr);
    ~sendmoney();
private slots:
    void on_pushButton_clicked();

private:
    Ui::sendmoney *ui;

};
class myclass{
public:
    QString money="0000",number;
    virtual void convertStringToInt() = 0;
};
class myclass2:public myclass{
private:
    int money1;
public:
    void convertStringToInt() override{
        bool ok;
        money = money.trimmed();
        qDebug()<<"str"<<money;
        money1=money.toInt(&ok);
        qDebug()<<"con"<<money1;
        if (!ok) {
            std::cout << "Failed to convert the string to an integer." << std::endl;
        }
    }
    int getmoney(){
        return money1;
    }
};


#endif // SENDMONEY_H
