#include "mainwindow.h"
#include <QApplication>
class login{
protected:

public:

};
class data:public login{
protected:

public:

};
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}
