#include "myaccount.h"
#include "ui_myaccount.h"
//#include "mainwo.h"
#include<QLineEdit>
#include<QFile>
#include<QTextStream>
#include<QApplication>
#include<QMessageBox>
#include"login.h"
#include<QDebug>
myaccount::myaccount(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::myaccount)
{
    ui->setupUi(this);
}
myaccount::~myaccount()
{
    delete ui;
}
void file2::receiveLineEditValue(const QString& lineEditText)
{
    qDebug() << "Received line edit value in File2:" << lineEditText;
}


void myaccount::on_pushButton_clicked()
{
    QString name1;
    name1=ui->lineEdit->text();
    QString path="C:/Users/hp/OneDrive/Desktop/oop - Copy";
    QString filename=path+"/"+name1+".txt";
    QFile file(filename);
    if(!file.open(QIODevice::ReadOnly|QFile::Text)){
        QMessageBox::warning(this,"File","ENTER NAME THEN PRESS DISPLAY");
    }
    else{

        QTextStream in(&file);
        QString name=in.readLine();     //search this and do
        QString phone=in.readLine();
        QString cnic=in.readLine();
        QString password1=in.readLine();
        ui->lineEdit->setText(name);
        ui->lineEdit_2->setText(phone);
        ui->lineEdit_3->setText(cnic);
        ui->lineEdit_4->setText(password1);
        file.flush();
        file.close();




    }
}

