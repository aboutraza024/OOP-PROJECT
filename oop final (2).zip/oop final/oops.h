#ifndef OOPS_H
#define OOPS_H
#include<iostream>
#include <QDialog>
#include<QFile>
#include<QTextStream>
#include<QMessageBox>
namespace Ui {
class oops;
class oops2;
}

class oops : public QDialog
{
    Q_OBJECT

public:
    explicit oops(QWidget *parent = nullptr);
    ~oops();

private:
    Ui::oops *ui;
private:
    QString firstname,secondname,password,conpassword,cnic,phone;

public:
    void setfname(QString fn){
        firstname=fn;
    }
    void setsname(QString sn){
        secondname=sn;
    }
    void setpword(QString pn){
        password=pn;
    }
    void setcpword(QString pn){
        conpassword=pn;
    }
    void setcnic1(QString pn){
        cnic=pn;
    }
    void setphone1(QString pn){
        phone=pn;
    }
    QString getpassword(){
        return password;
    }
};
class oops2:public oops{
private:
    int transaction,transactions=0;
    long int money=5000;
public:

    void settransaction(){
        transaction=transactions+1;
    }
    int gettransaction(){
        return transaction;
    }
    void setmoney(long int mo1){
        money=money-mo1;
    }
   long int getmoney(){
        return money;
    }

};

//#endif //oops 2

#endif // OOPS_H
//#endif

