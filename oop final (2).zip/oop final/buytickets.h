#ifndef BUYTICKETS_H
#define BUYTICKETS_H

#include <QDialog>

namespace Ui {
class buytickets;
}

class buytickets : public QDialog
{
    Q_OBJECT

public:
    explicit buytickets(QWidget *parent = nullptr);
    ~buytickets();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::buytickets *ui;
};

#endif // BUYTICKETS_H
