#ifndef TELENOR_H
#define TELENOR_H

#include <QDialog>

namespace Ui {
class telenor;
}

class telenor : public QDialog
{
    Q_OBJECT

public:
    explicit telenor(QWidget *parent = nullptr);
    ~telenor();

private slots:
    void on_pushButton_clicked();

private:
    Ui::telenor *ui;
};

#endif // TELENOR_H
