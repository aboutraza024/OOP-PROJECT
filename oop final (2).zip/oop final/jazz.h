#ifndef JAZZ_H
#define JAZZ_H

#include <QDialog>

namespace Ui {
class jazz;
}

class jazz : public QDialog
{
    Q_OBJECT

public:
    explicit jazz(QWidget *parent = nullptr);
    ~jazz();

private slots:
    void on_pushButton_clicked();

private:
    Ui::jazz *ui;
};

#endif // JAZZ_H
