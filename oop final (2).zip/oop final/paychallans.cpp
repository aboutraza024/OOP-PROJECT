#include "paychallans.h"
#include "ui_paychallans.h"
#include<QMessageBox>
#include"password.h"
#include<QFile>
#include<QTextStream>
#include"oops.h"
paychallans::paychallans(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::paychallans)
{
    ui->setupUi(this);
}

paychallans::~paychallans()
{
    delete ui;
}

void paychallans::on_pushButton_clicked()
{
    password p;
    QString pass=ui->lineEdit->text();
    p.setModal(true);
    p.exec();
    QString name1,amount;
    name1=ui->lineEdit_4->text();
    amount=ui->lineEdit_3->text();
    int amount1=amount.toInt();
    oops2 o1;

    password p1;
    p1.setModal(true);
    p1.exec();
    QString fee;
    QString path="C:/Users/hp/OneDrive/Desktop/oop - Copy";
    QString filename=path+"/"+name1+"money.txt";
    QFile file(filename);
    if(!file.open(QIODevice::ReadOnly|QFile::Text)){
        QMessageBox::warning(this,"File","Filen    is not open");
    }
    else{
        QTextStream in(&file);
        QString amount2=in.readLine();
        int amount3=amount2.toInt();
        amount3=amount3-amount1;
        QString path="C:/Users/hp/OneDrive/Desktop/oop - Copy";
        QString filename=path+"/"+name1+"money.txt";
        QFile file(filename);
        if(!file.open(QIODevice::WriteOnly|QFile::Text)){
            QMessageBox::warning(this,"File","Filen    is not open");
        }
        else{
            QTextStream out(&file);
            out<<amount3;
            QString path3="C:/Users/hp/OneDrive/Desktop/oop - Copy";
            QString filename3=path3+"/"+name1+"transaction.txt";
            QFile file3(filename3);
            if(!file3.open(QIODevice::Append|QFile::Text)){
                QMessageBox::warning(this,"File","ERROR");
            }
            else{
                QTextStream write(&file3);
                write<<"\n\n"<<name1<<" has been paid challans of RS "<<amount1;
                file3.flush();
                file3.close();
                file.flush();
                file.close();
            }
        }
    }

}


