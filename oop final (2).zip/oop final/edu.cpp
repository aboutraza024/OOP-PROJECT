#include "edu.h"
#include "ui_edu.h"
#include"password.h"
#include"oops.h"
#include<QMessageBox>
#include<QLineEdit>
#include<QString>
#include<QDebug>
#include<QCoreApplication>
using namespace std;
edu::edu(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::edu)
{
    ui->setupUi(this);
}

edu::~edu()
{
    delete ui;
}

void edu::on_pushButton_clicked()
{
    QString name1,amount;
    name1=ui->lineEdit_3->text();
    amount=ui->lineEdit_4->text();
    int amount1=amount.toInt();
    oops2 o1;
    long int money;
    money=o1.getmoney();

    QString pass=ui->lineEdit->text();

    QString fee;
    QString path="C:/Users/hp/OneDrive/Desktop/oop - Copy";
    QString filename=path+"/"+name1+"money.txt";
    QFile file(filename);
    if(!file.open(QIODevice::ReadOnly|QFile::Text)){
        QMessageBox::warning(this,"File","Filen    is not open");
    }
    else{
        QTextStream in(&file);
        QString amount2=in.readLine();
        int amount3=amount2.toInt();
       // amount3=amount3.trimmed();
        amount3=amount3-amount1;
        QString path="C:/Users/hp/OneDrive/Desktop/oop - Copy";
        QString filename=path+"/"+name1+"money.txt";
        QFile file(filename);
        if(!file.open(QIODevice::WriteOnly|QFile::Text)){
            QMessageBox::warning(this,"File","Filen    is not open");
        }
        else{
            if(amount1>amount3){
                QMessageBox::warning(this,"AMOUNT","INSUFFICIENT AMOUNT");
            }
            else{
                password p1;
                p1.setModal(true);
                p1.exec();
                QTextStream out(&file);
                out<<amount3;
                QString path3="C:/Users/hp/OneDrive/Desktop/oop - Copy";
                QString filename3=path3+"/"+name1+"transaction.txt";
                QFile file3(filename3);
                if(!file3.open(QIODevice::Append|QFile::Text)){
                    QMessageBox::warning(this,"File","ERROR");
                }
                else{
                    QTextStream write(&file3);
                    write<<"\n"<<name1<<" has been paid ypur education fee RS "<<amount;
                    file3.flush();
                    file3.close();
                }
            }
        }
            }
}

