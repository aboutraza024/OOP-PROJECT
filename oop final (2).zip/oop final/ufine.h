#ifndef UFINE_H
#define UFINE_H

#include <QDialog>

namespace Ui {
class ufine;
}

class ufine : public QDialog
{
    Q_OBJECT

public:
    explicit ufine(QWidget *parent = nullptr);
    ~ufine();

private slots:
    void on_pushButton_clicked();

private:
    Ui::ufine *ui;
};

#endif // UFINE_H
