#include "number.h"
#include "ui_number.h"
#include<QMessageBox>
#include"password.h"
#include<QFile>
#include"oops.h"
#include<QTextStream>

number::number(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::number)
{
    ui->setupUi(this);
}

number::~number()
{
    delete ui;
}

void number::on_pushButton_clicked()
{
    password p1;
    p1.setModal(true);
    p1.exec();
    //QMessageBox::information(this,"TRANSACTION","TRANSACTION COMPLETED SUCCESSFULLY");

    QString name1,amount;
    name1=ui->lineEdit_3->text();
    amount=ui->lineEdit_2->text();
    int amount1=amount.toInt();
    oops2 o1;
    QString path="C:/Users/hp/OneDrive/Desktop/oop - Copy";
    QString filename=path+"/"+name1+"money.txt";
    QFile file(filename);
    if(!file.open(QIODevice::ReadOnly|QFile::Text)){
        QMessageBox::warning(this,"File","Filen    is not open");
    }
    else{
        QTextStream in(&file);
        QString amount2=in.readLine();
        int amount3=amount2.toInt();
        // amount3=amount3.trimmed();
        amount3=amount3-amount1;
        QString path="C:/Users/hp/OneDrive/Desktop/oop - Copy";
        QString filename=path+"/"+name1+"money.txt";
        QFile file(filename);
        if(!file.open(QIODevice::WriteOnly|QFile::Text)){
            QMessageBox::warning(this,"File","Filen is not open");
        }
        else{
            QString path3="C:/Users/hp/OneDrive/Desktop/oop - Copy";
            QString filename3=path3+"/"+name1+"transaction.txt";
            QFile file3(filename3);
            if(!file3.open(QIODevice::Append|QFile::Text)){
                QMessageBox::warning(this,"File","ERROR");
            }
            else{
                QTextStream write(&file3);
                write<<"\n"<<name1<<" has been send mobile load RS "<<amount;
                file.flush();
                file.close();
            }

        }
    }
}

