#include "registre.h"
#include "ui_registre.h"
//#include "mainwo.h"
#include<QMessageBox>
#include<QFile>
#include<QTextStream>
#include"oops.h"
registre::registre(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::registre)
{
    ui->setupUi(this);
}

registre::~registre()
{
    delete ui;
}

void registre::on_pushButton_clicked()
{
    oops2 o1,o2;
        QString firstname;
        firstname=ui->lineEdit->text();
        QString path="C:/Users/hp/OneDrive/Desktop/oop - Copy";
        QString filename=path+"/"+firstname+".txt";
        QFile file(filename);
        if(!file.open(QIODevice::WriteOnly|QFile::Text)){
            QMessageBox::warning(this,"File","File is not open");
        }
        else{
            QTextStream out(&file);
            QString secondname,password,conpassword,cnic,phone;
            //firstname=ui->lineEdit->text();
            out<<firstname;
            o1.setfname(firstname);
            //secondname=ui->lineEdit_2->text();
            out<<secondname<<"\n";
            //out1<<secondname<<"\n";
            o1.setsname(secondname);
            cnic=ui->lineEdit_3->text();
            out<<cnic<<"\n";

            o1.setcnic1(cnic);

            phone=ui->lineEdit_4->text();
            out<<phone<<"\n";
            o1.setphone1(phone);

            password=ui->lineEdit_5->text();
            conpassword=ui->lineEdit_6->text();
            if(password==conpassword){
                out<<password<<"\n"<<conpassword;
                //out1<<password<<conpassword<<"\n";
                o1.setpword(password);
                o1.setcpword(conpassword);
                QMessageBox::information(this,"Welcome"," LOGIN ACCOUNT TO START ");
                //mainwo l1;
                //l1.setModal(true);
                //l1.exec();
                file.flush();
                file.close();

            }

            else{
                QMessageBox::critical(this,"Password","YOUR PASSWORD IS WRONG");
                file.flush();   // use do while and modules
                file.close();
            }
        }



        QFile file1("C:/Users/hp/OneDrive/Desktop/oop - Copy/double23.txt");
        if(!file1.open(QIODevice::WriteOnly|QFile::Text)){
            QMessageBox::warning(this,"File","File is not open");
        }
        else{
            QTextStream out1(&file1);
            QString firstname1,secondname1,password1,conpassword1,cnic1,phone1;
            firstname1=ui->lineEdit->text();
            out1<<firstname1;
            o2.setfname(firstname1);
            //secondname1=ui->lineEdit_2->text();
            out1<<secondname1<<"\n";
            o2.setsname(secondname1);
            cnic1=ui->lineEdit_3->text();
            out1<<cnic1<<"\n";
            o2.setcnic1(cnic1);
            phone1=ui->lineEdit_4->text();
            out1<<phone1<<"\n";
            o2.setphone1(phone1);
            password1=ui->lineEdit_5->text();
            conpassword1=ui->lineEdit_6->text();
            if(password1==conpassword1){
                out1<<password1<<"\n"<<conpassword1;
                //out1<<password<<conpassword<<"\n";
                o2.setpword(password1);
                o2.setcpword(conpassword1);
                QMessageBox::information(this,"Welcome"," Welcome To Branchless Banking");
                file1.flush();
                file1.close();
            }
            else{
                QMessageBox::critical(this,"Password","YOUR PASSWORD IS WRONG");
                file1.flush();
                file1.close();

            }
    }
}



