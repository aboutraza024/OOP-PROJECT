#ifndef NUMBER1_H
#define NUMBER1_H

#include <QDialog>

namespace Ui {
class number1;
}

class number1 : public QDialog
{
    Q_OBJECT

public:
    explicit number1(QWidget *parent = nullptr);
    ~number1();

private slots:
    void on_pushButton_clicked();

private:
    Ui::number1 *ui;
};

#endif // NUMBER1_H
