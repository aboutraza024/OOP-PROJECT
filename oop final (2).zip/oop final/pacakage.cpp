#include "pacakage.h"
#include "ui_pacakage.h"
#include"number.h"
#include"jazz.h"
#include"zong.h"
#include"ufine.h"
#include"telenor.h"
pacakage::pacakage(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::pacakage)
{
    ui->setupUi(this);
}

pacakage::~pacakage()
{
    delete ui;
}

void pacakage::on_pushButton_clicked()
{
    jazz j1;
    j1.setModal(true);
    j1.exec();
}


void pacakage::on_pushButton_2_clicked()
{
    zong z1;
    z1.setModal(true);
    z1.exec();
}


void pacakage::on_pushButton_4_clicked()
{
    telenor t1;
    t1.setModal(true);
    t1.exec();
}


void pacakage::on_pushButton_3_clicked()
{
    ufine u1;
    u1.setModal(true);
    u1.exec();
}

