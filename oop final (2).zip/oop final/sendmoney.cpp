#include "sendmoney.h"
#include "ui_sendmoney.h"
#include"password.h"
#include"oops.h"
#include<QMessageBox>
#include<login.h>
sendmoney::sendmoney(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::sendmoney)
{
    ui->setupUi(this);
}

sendmoney::~sendmoney()
{
    delete ui;
}

void sendmoney::on_pushButton_clicked()
{
    file2 l1;
    QString name1, name2;
    name1=ui->lineEdit_3->text();

    myclass2 obj;

     obj.number=ui->lineEdit->text();
     obj.money=ui->lineEdit_2->text();
     obj.convertStringToInt();
     int mo1=obj.getmoney();
     QString path="C:/Users/hp/OneDrive/Desktop/oop - Copy";
     QString filename=path+"/"+name1+"money.txt";
     QFile file(filename);
     if(!file.open(QIODevice::ReadOnly|QFile::Text)){
         QMessageBox::warning(this,"File","ERROR");
     }
     else{
         QTextStream read(&file);
         QString money=read.readLine();
         //money = money.trimmed();
         int money1;
         money1=money.toInt();
         money1=money1-mo1;
         if(mo1>money1){
             QMessageBox::critical(this,"MONEY","INSUFFICIENT BALANCE");

         }
         else{
             password p;
             p.setModal(true);
             p.exec();
             QString path1="C:/Users/hp/OneDrive/Desktop/oop - Copy";
             QString filename1=path1+"/"+name1+"money.txt";
             QFile file1(filename1);
             if(!file1.open(QIODevice::WriteOnly|QFile::Text)){
                 QMessageBox::warning(this,"File","ERROR");
             }
             else{
                 QTextStream write(&file1);
                 write<<money1;


             }
         }
         }

    name2=ui->lineEdit_4->text();
     QString p1="C:/Users/hp/OneDrive/Desktop/oop - Copy";
    QString f1=p1+"/"+name2+"money.txt";
     QFile file4(f1);
    if(!file4.open(QIODevice::ReadOnly|QFile::Text)){
         QMessageBox::information(this,"file","ERROR");
     }
     else{
         QTextStream in(&f1);
         QString money9=in.readLine();
         qDebug()<<money9;
         qDebug()<<money9;
         money9 = money9.trimmed();
         int money5=money9.toInt();
         qDebug()<<money5;
         //qDebug()<<money5
         money5=money5+mo1;
         //qDebug()<<money5;
         QString path1="C:/Users/hp/OneDrive/Desktop/oop - Copy";
         QString filename1=path1+"/"+name2+"money.txt";
         QFile file1(filename1);
         if(!file1.open(QIODevice::WriteOnly|QFile::Text)){
             QMessageBox::warning(this,"File","ERROR");
         }
         else{
             QTextStream write(&file1);
             write<<money5;
             QString path3="C:/Users/hp/OneDrive/Desktop/oop - Copy";
             QString filename3=path3+"/"+name1+"transaction.txt";
             QFile file3(filename3);
             if(!file3.open(QIODevice::Append|QFile::Text)){
                 QMessageBox::warning(this,"File","ERROR");
             }
             else{
                 QTextStream write(&file3);
                 write<<"\n"<<name1<<" has been send "<<mo1<<" to "<<name2;
                 file.flush();
                 file.close();
                 file3.flush();
                 file3.close();
             }
         }
     }




}



