#include "forgetpassword.h"
#include "ui_forgetpassword.h"
#include<QMessageBox>
forgetpassword::forgetpassword(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::forgetpassword)
{
    ui->setupUi(this);
}

forgetpassword::~forgetpassword()
{
    delete ui;
}

void forgetpassword::on_pushButton_clicked()
{
    QMessageBox::information(this,"PASSWORD","VERIFICATION CODE SENDED SUCCESSFULLY");
}

