#include "transaction.h"
#include "ui_transaction.h"
#include<QFile>
#include<QTextStream>
#include<QMessageBox>
#include<QString>
#include"data.h"
transaction::transaction(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::transaction)
{
    ui->setupUi(this);
}

transaction::~transaction()
{
    delete ui;
}

void transaction::on_pushButton_clicked()
{
    //int m=2000;
    QString name1=ui->lineEdit->text();
    QString path0="C:/Users/hp/OneDrive/Desktop/oop - Copy";
    QString filename0=path0+"/"+name1+"transaction.txt";
    QFile file(filename0);
    if(!file.open(QIODevice::ReadOnly|QFile::Text)){
        QMessageBox::warning(this,"File","Filen    is not open");
    }
    else{
        QTextStream in(&file);
        QString text=in.readAll();
        qDebug()<<"\n\n\n\n\n\n\n\n\n";
        ui->plainTextEdit->setPlainText(text);

    }
}


void transaction::on_pushButton_2_clicked()
{
    QString name1=ui->lineEdit->text();
    QString amount;
    QString path0="C:/Users/hp/OneDrive/Desktop/oop - Copy";
    QString filename0=path0+"/"+name1+"money.txt";
    QFile file(filename0);
    if(!file.open(QIODevice::ReadOnly|QFile::Text)){
        QMessageBox::warning(this,"File","ERROR");
    }
    else{
        QTextStream in(&file);
        QString text=in.readLine();
       // qDebug()<<"\n\n\n\n\n\n\n\n\n";
        ui->lineEdit_2->setText(text);
        file.flush();
        file.close();

    }
}

