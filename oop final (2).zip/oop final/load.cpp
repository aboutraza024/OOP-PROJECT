#include "load.h"
#include "ui_load.h"
#include"number.h"
load::load(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::load)
{
    ui->setupUi(this);

}

load::~load()
{
    delete ui;
}

void load::on_pushButton_2_clicked()
{
    number n1;
    n1.setModal(true);
    n1.exec();
}


void load::on_pushButton_3_clicked()
{
   number n1;
    n1.setModal(true);
    n1.exec();
}


void load::on_pushButton_4_clicked()
{
    number n1;
    n1.setModal(true);
    n1.exec();
}


void load::on_pushButton_5_clicked()
{
    number n1;
    n1.setModal(true);
    n1.exec();
}

