#include "oops.h"
#include "ui_oops.h"

oops::oops(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::oops)
{
    ui->setupUi(this);
}

oops::~oops()
{
    delete ui;
}
