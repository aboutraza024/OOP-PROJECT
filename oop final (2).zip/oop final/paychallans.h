#ifndef PAYCHALLANS_H
#define PAYCHALLANS_H

#include <QDialog>

namespace Ui {
class paychallans;
}

class paychallans : public QDialog
{
    Q_OBJECT

public:
    explicit paychallans(QWidget *parent = nullptr);
    ~paychallans();

private slots:
    void on_pushButton_clicked();

private:
    Ui::paychallans *ui;
};

#endif // PAYCHALLANS_H
