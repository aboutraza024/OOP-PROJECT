#include "password.h"
#include "ui_password.h"
#include"oops.h"
#include<QMessageBox>
#include<QDebug>
#include<QFile>
#include<iostream>
password::password(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::password)
{
    ui->setupUi(this);
}

password::~password()
{
    delete ui;
}

void password::on_pushButton_clicked()
{
    QString name1=ui->lineEdit_2->text();
    QString path="C:/Users/hp/OneDrive/Desktop/oop - Copy";
    QString filename=path+"/"+name1+".txt";
    QFile file(filename);
    if(!file.open(QIODevice::ReadOnly|QFile::Text)){
        //QMessageBox::warning(this,"File","File is not open");
    }
    QTextStream in(&file);
    QString name=in.readLine();     //search this and do
    QString phone=in.readLine();
    QString cnic=in.readLine();
    QString password1=in.readLine();
    QString password2=in.readLine();


  //  QString pass;
    oops2 obj;

    QString pass=ui->lineEdit->text();
    if(pass==password1){
        //here - money.  and display balance in my account
        obj.settransaction();
        qDebug()<<obj.gettransaction();
        QMessageBox::information(this,"SEND MONEY","TRANSACTION COMPLETED SUCCESSFULLY");

    }
    else{
      QMessageBox::warning(this,"SEND MONEY","WRONG PASSWORD");
    }
}

