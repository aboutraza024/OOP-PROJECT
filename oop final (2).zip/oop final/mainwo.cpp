#include "mainwo.h"
#include "ui_mainwo.h"
#include"myaccount.h"
#include"sendmoney.h"
#include"paychallans.h"
//#include"oops.h"
#include"edu.h"
#include"buytickets.h"
#include"load.h"
#include"pacakage.h"
#include<QFile>
#include<QApplication>
#include<QMessageBox>
#include"transaction.h"
#include<QLineEdit>
//#include"oops.h"
mainwo::mainwo(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::mainwo)
{
    ui->setupUi(this);
}

mainwo::~mainwo()
{
    delete ui;
}

void mainwo::on_pushButton_clicked()
{
    myaccount m1;
    m1.setModal(true);
    m1.exec();

}


void mainwo::on_pushButton_2_clicked()
{
    sendmoney s1;                        //make condition to check password
    s1.setModal(true);
    s1.exec();
}


void mainwo::on_pushButton_3_clicked()
{
    paychallans p1;
    p1.setModal(true);
    p1.exec();

}


void mainwo::on_pushButton_4_clicked()
{
    edu e1;
    e1.setModal(true);
    e1.exec();
}


void mainwo::on_pushButton_7_clicked()
{
    buytickets b1;
    b1.setModal(true);
    b1.exec();
}


void mainwo::on_pushButton_5_clicked()
{
    load l1;
    l1.setModal(true);
    l1.exec();
}


void mainwo::on_pushButton_6_clicked()
{
    pacakage p1;
    p1.setModal(true);
    p1.exec();
}


void mainwo::on_pushButton_8_clicked()
{
  //oops2 o1;
    transaction t1;
    t1.setModal(true);
    t1.exec();
}


