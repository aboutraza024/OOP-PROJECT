#ifndef LOGIN_H
#define LOGIN_H
#include<QString>
#include <QDialog>

namespace Ui {
class login;
}

class login : public QDialog
{
    Q_OBJECT

public:
    explicit login(QWidget *parent = nullptr);
    ~login();

private slots:
    void on_lsubmit_clicked();

    void on_mainwindow_clicked();

    void on_label_3_customContextMenuRequested(const QPoint &pos);

    void on_label_3_linkActivated(const QString &link);

    void on_pushButton_clicked();

private:
    Ui::login *ui;
};
class file2{
private:
    QString name1="";
public:
  void receiveLineEditValue(const QString& lineEditText);
    void setname(QString name){
        name1=name;
    }
    QString getname(){
        return name1;
    }
};
#endif // LOGIN_H
