#ifndef PACAKAGE_H
#define PACAKAGE_H

#include <QDialog>

namespace Ui {
class pacakage;
}

class pacakage : public QDialog
{
    Q_OBJECT

public:
    explicit pacakage(QWidget *parent = nullptr);
    ~pacakage();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::pacakage *ui;
};

#endif // PACAKAGE_H
