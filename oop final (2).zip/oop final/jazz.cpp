#include "jazz.h"
#include "ui_jazz.h"
#include"number1.h"
#include<QFile>
#include<QTextStream>
#include<iostream>
#include<QMessageBox>
jazz::jazz(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::jazz)
{
    ui->setupUi(this);
}

jazz::~jazz()
{
    delete ui;
}

void jazz::on_pushButton_clicked()
{
    number1 n1;
    n1.setModal(true);
    n1.exec();
    int pkg =600;
    QString name1=ui->lineEdit->text();
    QString path="C:/Users/hp/OneDrive/Desktop/oop - Copy";
    QString filename=path+"/"+name1+"money.txt";
    QFile file(filename);
    if(!file.open(QIODevice::ReadOnly|QFile::Text)){
        QMessageBox::warning(this,"File","Filen    is not open");
    }
    else{
        QTextStream read(&file);
        QString money=read.readLine();
        int money1;
        money1=money.toInt();
        money1=money1-pkg;
        QString path1="C:/Users/hp/OneDrive/Desktop/oop - Copy";
        QString filename1=path1+"/"+name1+"money.txt";
        QFile file1(filename1);
        if(!file1.open(QIODevice::WriteOnly|QFile::Text)){
            QMessageBox::warning(this,"File","File is not open");
        }
        else{
            QTextStream write(&file1);
            write<<money1;
            //QTextStream out(&file);
           // out<<amount3;
            QString path3="C:/Users/hp/OneDrive/Desktop/oop - Copy";
            QString filename3=path3+"/"+name1+"transaction.txt";
            QFile file3(filename3);
            if(!file3.open(QIODevice::Append|QFile::Text)){
                QMessageBox::warning(this,"File","ERROR");
            }
            else{
                QTextStream write(&file3);
                write<<"\n"<<name1<<" has been send mobile pacakage of RS "<<pkg;
                file3.flush();
                file3.close();
            }



        }
    }
}

