#ifndef EDU_H
#define EDU_H

#include <QDialog>

namespace Ui {
class edu;
}

class edu : public QDialog
{
    Q_OBJECT

public:
    explicit edu(QWidget *parent = nullptr);
    ~edu();

private slots:
    void on_pushButton_clicked();

private:
    Ui::edu *ui;
};

#endif // EDU_H
