#ifndef LOAD_H
#define LOAD_H

#include <QDialog>

namespace Ui {
class load;
}

class load : public QDialog
{
    Q_OBJECT

public:
    explicit load(QWidget *parent = nullptr);
    ~load();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

private:
    Ui::load *ui;
};

#endif // LOAD_H
