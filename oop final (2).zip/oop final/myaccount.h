#ifndef MYACCOUNT_H
#define MYACCOUNT_H

#include <QDialog>

namespace Ui {
class myaccount;
}

class myaccount : public QDialog
{
    Q_OBJECT

public:
    explicit myaccount(QWidget *parent = nullptr);
    ~myaccount();

private slots:
    void on_pushButton_clicked();

private:
    Ui::myaccount *ui;
};

#endif // MYACCOUNT_H
