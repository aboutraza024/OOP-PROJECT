#include "login.h"
#include "ui_login.h"
#include "mainwo.h"
#include<QFile>
#include<QMessageBox>
#include"oops.h"
#include"forgetpassword.h"
login::login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::login)
{
    ui->setupUi(this);
}

login::~login()
{
    delete ui;
}

void login::on_lsubmit_clicked()
{

}


void login::on_mainwindow_clicked()
{
    oops2 o1;
    file2 l1;
    QString name1=ui->lname->text();
    l1.setname(name1);
    QString password=ui->lpassword->text();
    QString path1="C:/Users/hp/OneDrive/Desktop/oop - Copy";
    QString filename1=path1+"/"+name1+"money.txt";
    l1.setname(name1);
    QFile file1(filename1);
    if(!file1.open(QIODevice::WriteOnly|QFile::Text)){
        QMessageBox::warning(this,"File","File is not open");
    }
    else{
        QTextStream in(&file1);
        in<<o1.getmoney();
    }
    file2 file2;
    file2.receiveLineEditValue(name1);
    oops2 obj;
    //QString firstname;
    //firstname=ui->lineEdit->text();
    QString path="C:/Users/hp/OneDrive/Desktop/oop - Copy";
    QString filename=path+"/"+name1+".txt";
    QFile file(filename);
    if(!file.open(QIODevice::ReadOnly|QFile::Text)){
        QMessageBox::warning(this,"File","wrong password");
    }
        else{
            QTextStream in(&file);
            QString name=in.readLine();     //search this and do
            QString phone=in.readLine();
            QString cnic=in.readLine();
            QString password1=in.readLine();
            //qDebug()<<password1;
            QString password2=in.readLine();
            qDebug()<<password1;
            QString name1=ui->lname->text();
          //  QString password=ui->lpassword->text();
            if(name==name1&&password1==password){
                QMessageBox::information(this,"LOGIN","LOGIN SUCCESSFULLY");
                obj.setpword(password1);
                mainwo m1;
                m1.setModal(true);
                m1.exec();
                //QString path="C:/Users/hp/OneDrive/Desktop/oop - Copy";
               // QString filename=path+"/"+name1+"MONEY.txt";
             //   QFile file(filename);
                QTextStream write(&file1);
                //write<<money5;
                QString path3="C:/Users/hp/OneDrive/Desktop/oop - Copy";
                QString filename3=path1+"/"+name1+"transaction.txt";
                QFile file3(filename3);
                if(!file3.open(QIODevice::Append|QFile::Text)){
                    QMessageBox::warning(this,"File","File         is not open");
                }
                else{
                    QTextStream write(&file3);
                    write<<"TRANSACTION HISTORY";
                    file.flush();
                    file.close();
                }
                }
            else{
                QMessageBox::warning(this,"LOGIN","INCORRECT PASSWORD OR NAME");
            }
        }
    }

void login::on_pushButton_clicked()
{
    forgetpassword f1;
    f1.setModal(true);
    f1.exec();

}

