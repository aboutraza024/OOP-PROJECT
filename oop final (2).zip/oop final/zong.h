#ifndef ZONG_H
#define ZONG_H

#include <QDialog>

namespace Ui {
class zong;
}

class zong : public QDialog
{
    Q_OBJECT

public:
    explicit zong(QWidget *parent = nullptr);
    ~zong();

private slots:
    void on_pushButton_clicked();

private:
    Ui::zong *ui;
};

#endif // ZONG_H
